<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
          $sql = "SELECT `CourseCode`,`CourseHr`,`room`,`days`,`timeslot` FROM `course`"; 
     mysql_select_db("myproject");
     $query = mysql_query($sql);
     echo '<table class="table table-bordered table-striped table-hover ">';
     echo '<thead>';
     echo '<tr>';
     echo '<th>Course Code</th>';
     echo '<th>Course Hour</th>';
     echo '<th>Lecture room</th>';
     echo '<th>Days of lecture</th>';
     echo '<th>Time</th>';
     echo '</tr>';
     echo '</thead>';
     echo '<thody>';
     while ($row = mysql_fetch_array($query)) {
         echo '<tr>'
              .'<td>'.$row["CourseCode"].'</td>'
              .'<td>'.$row["CourseHr"].'</td>'
              .'<td>'.$row["room"].'</td>'
              .'<td>'.$row["days"].'</td>'
              .'<td>'.$row["timeslot"].'</td>';
         echo '</tr';
         echo '<br />';
     }
     echo '</tbody>';
     echo '</table>';
        ?>
    </body>
</html>
