function listcours(){
     $host = 'localhost:3306';
     $user = 'root';
     $pass = '';
     $con = mysql_connect($host,$user,$pass);
     if($con == false){
          die('cant connect');
     }
     mysql_select_db("myproject");
     $us = $_SESSION['username'];
     $sqlc = "SELECT `Dept` FROM `timetableofficer` WHERE `Username`= '$us'";
     $rowc = mysql_fetch_array(mysql_query($sqlc));
     $sql= "SELECT `CourseCode`,`CourseHr` FROM `course` WHERE (`CourseType` = 'DEPT' or `CourseType` = 'COMBINED') and `Dept` = '$rowc'";
     $query = mysql_query($sql);
     if(!$query){
         echo "couldnt query the database";
     }
     else{
         while ($row = mysql_fetch_array($query)) {
             echo '<option value="'.$row['CourseCode'].'">'.$row['CourseCode'].' ('.$row[CourseHr].' Credit hour)'.'</option>';  
         }
     }
}